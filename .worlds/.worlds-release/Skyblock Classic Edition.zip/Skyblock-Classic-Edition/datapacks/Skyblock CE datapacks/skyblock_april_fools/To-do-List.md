**To Do List April Fool:**
- aggiungere prossimo pesce d'aprile 2025
- testare tutto
- correzioni delle prestazioni e fix bug vari per April