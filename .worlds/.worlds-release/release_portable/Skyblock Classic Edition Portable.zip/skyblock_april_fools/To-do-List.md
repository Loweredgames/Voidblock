**To Do List April Fool:**
- risolvere il tellraw sul pvn
- aggiungere prossimo pesce d'aprile 2025
- testare tutto
- correzioni delle prestazioni e fix bug vari per April