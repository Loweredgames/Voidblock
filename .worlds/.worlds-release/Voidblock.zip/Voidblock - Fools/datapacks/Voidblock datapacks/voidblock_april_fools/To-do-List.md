**To Do List April Fool:**
- risolvere il tellraw sul pvn
- fare conversione totale
- testare tutto
- aggiungere prossimo pesce d'aprile 2026