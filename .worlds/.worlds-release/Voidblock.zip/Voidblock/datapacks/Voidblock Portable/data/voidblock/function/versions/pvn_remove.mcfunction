#Copyright (C) Loweredgames (Lorenzo Giannini)
#Contacted:<https://github.com/Loweredgames>
#This Source Code Form is subject to the terms of the License.
#NOT OFFICIAL MINECRAFT PRODUCT. NOT APPROVED BY OR ASSOCIATED WITH MOJANG STUDIO.
#READING THE COPYRIGHT (C): <https://www.minecraft.net/en-us/terms>


###PVN REMOVE BUILDING (AGGIUNGERE I PVN SOLO PER LE VERSIONI DI SVILUPPO DA RIMUOVERE, LE VERSIONI PIU VECCHIE DEVONO ESSERE RIMOSSE PER LO SPAZIO)


##???? - FUTURA (PROSSIMA VERSIONE)


##26.1.2/26.2/26.3 - STABILE <-- QUI
#scoreboard objectives remove PVN_0_mc263a
scoreboard objectives remove PVN_0_mc262
scoreboard objectives remove PVN_0_mc262a
scoreboard objectives remove PVN_0_mc261
scoreboard objectives remove PVN_0_mc261b
scoreboard objectives remove PVN_0_mc261a


##1.21/1.21.1/1.21.2/1.21.3/1.21.4/1.21.5/1.21.6/1.21.7/1.21.8/1.21.9/1.21.10/1.21.11 - LTS STABILE
scoreboard objectives remove PVN_0_mc12111a
scoreboard objectives remove PVN_0_mc12110
scoreboard objectives remove PVN_0_mc1219
scoreboard objectives remove PVN_0_mc1219e
scoreboard objectives remove PVN_0_mc1219d
scoreboard objectives remove PVN_0_mc1219c
scoreboard objectives remove PVN_0_mc1219b
scoreboard objectives remove 1.21.8_PVN_1
scoreboard objectives remove 1.21.8_PVN_0
scoreboard objectives remove 1.21.6_PVN_0
scoreboard objectives remove 1.21.5_PVN_0
scoreboard objectives remove 1.21.5_PVN_0e
scoreboard objectives remove 1.21.5_PVN_0d
scoreboard objectives remove 1.21.5_PVN_0c
scoreboard objectives remove 1.21.5_PVN_0b
scoreboard objectives remove 1.21.5_PVN_0a
scoreboard objectives remove 1.21.4_PVN_0
scoreboard objectives remove 1.21.4_PVN_0b
scoreboard objectives remove 1.21.4_PVN_0a


##1.21/1.21.1 - VECCHIA STABILE
scoreboard objectives remove 1.21_PVN_0
scoreboard objectives remove 1.21_PVN_0d
scoreboard objectives remove 1.21_PVN_0c
scoreboard objectives remove 1.21_PVN_0b
scoreboard objectives remove 1.21_PVN_0a


##1.20.6 - LTS STABILE
scoreboard objectives remove 1.20.6_PVN_0
scoreboard objectives remove 1.20.6_PVN_0d
scoreboard objectives remove 1.20.6_PVN_0c
scoreboard objectives remove 1.20.6_PVN_0b
scoreboard objectives remove 1.20.6_PVN_0a


##1.20.5/1.20.6 - VECCHIA STABILE
scoreboard objectives remove 1.20.5_PVN_0
scoreboard objectives remove 1.20.5_PVN_0h
scoreboard objectives remove 1.20.5_PVN_0g
scoreboard objectives remove 1.20.5_PVN_0f
scoreboard objectives remove 1.20.5_PVN_0e
scoreboard objectives remove 1.20.5_PVN_0d
scoreboard objectives remove 1.20.5_PVN_0c
scoreboard objectives remove 1.20.5_PVN_0b
scoreboard objectives remove 1.20.5_PVN_0a


##1.20.3/1.20.4 - VECCHIA STABILE
scoreboard objectives remove 1.20.3_PVN_1
scoreboard objectives remove 1.20.3_PVN_1b
scoreboard objectives remove 1.20.3_PVN_1a
scoreboard objectives remove 1.20.3_PVN_0
scoreboard objectives remove 1.20.3_PVN_0d
scoreboard objectives remove 1.20.3_PVN_0c
scoreboard objectives remove 1.20.3_PVN_0b
scoreboard objectives remove 1.20.3_PVN_0a


##1.20.1/1.20.2 - LTS VECCHIA
scoreboard objectives remove 1.20.2_PVN_1
scoreboard objectives remove 1.20.2_PVN_0
scoreboard objectives remove 1.20.2_PVN_0c
scoreboard objectives remove 1.20.2_PVN_0b
scoreboard objectives remove 1.20.2_PVN_0a
scoreboard objectives remove PVN_12


##1.19.4 - VECCHIA INSTABILE
scoreboard objectives remove PVN_OLD
scoreboard objectives remove PVN_10
scoreboard objectives remove PVN_10a
scoreboard objectives remove PVN_10b
scoreboard objectives remove PVN_10c
scoreboard objectives remove PVN_10d
scoreboard objectives remove PVN_10e
scoreboard objectives remove PVN_10f
scoreboard objectives remove PVN_10g
scoreboard objectives remove PVN_10h
scoreboard objectives remove PVN_10i
scoreboard objectives remove PVN_9


##1.17.1/1.18.2 VECCHIA INSTABILE (PROSSIMA RIMOZIONE NELLA PROSSIMA GRANDE VERSIONE SE CI SARA)
scoreboard objectives remove PVN_8
scoreboard objectives remove PVN_7
scoreboard objectives remove PVN_6
scoreboard objectives remove PVN_5
scoreboard objectives remove PVN_4
scoreboard objectives remove PVN_3
scoreboard objectives remove PVN_2
scoreboard objectives remove PVN_1
scoreboard objectives remove PVN_0